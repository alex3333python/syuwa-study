import '../models/app_language.dart';
import '../models/lesson.dart';
import '../models/question.dart';
import 'equal_share_language_support.dart';

// Grade 3 division lessons use the existing choice-based LessonScreen while
// keeping metadata for future number input, diagram, and written-answer UIs.
final List<Lesson> grade3DivisionLessons = [
  Lesson(
    id: 7,
    levelId: 2,
    type: LessonType.practice,
    title: '同じ数ずつ分ける',
    description: '全部の数を、何人かで同じ数ずつ分けて、1人分を求めます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      _learn(
        id: 'division-equal-share-learn',
        title: '学習しよう',
        school:
            '6このいちごを3人で同じ数ずつ分けます。いちごを1こずつ3人のお皿に置き、もう一度1こずつ置くと、どのお皿も2こになります。このとき式は、6 ÷ 3 = 2 と書き、「6わる3は2」と読みます。1人分を知りたいときに使う計算が、わり算です。',
        easy: 'いちごが6こあります。3人に同じ数で分けます。1こずつお皿に入れると、1人2こになります。6 ÷ 3 = 2 です。',
        native: {
          AppLanguage.portuguese:
              'Há 6 morangos. Vamos dividir igualmente entre 3 pessoas. Colocando 1 morango de cada vez em cada prato, cada pessoa fica com 2. Escrevemos 6 ÷ 3 = 2.',
          AppLanguage.tagalog:
              'May 6 na strawberry. Hahatiin ito nang pantay sa 3 tao. Kapag naglagay ng tig-isa sa bawat plato, bawat tao ay may 2. Isinusulat ito bilang 6 ÷ 3 = 2.',
          AppLanguage.vietnamese:
              'Có 6 quả dâu. Chia đều cho 3 người. Mỗi lần đặt 1 quả vào mỗi đĩa thì mỗi người được 2 quả. Ta viết 6 ÷ 3 = 2.',
        },
      ),
      _learn(
        id: 'division-equal-share-words',
        title: 'ことばを知ろう',
        school: '大事な言葉は「同じ数ずつ」「分ける」「1人分」「全部で」です。',
        easy: '「同じ数ずつ」は、みんなが同じ数になることです。「1人分」は、1人がもらう数です。',
      ),
      LessonStep(
        id: 'division-equal-share-guided',
        type: LessonStepType.guidedPractice,
        title: 'いっしょにとこう',
        questions: [
          _q(
            id: 7101,
            type: 'select_picture',
            school: '6このりんごを2人で同じ数ずつ分けます。1人分は何こですか。',
            easy: 'りんごが6こあります。2人に同じ数で分けます。1人は何こもらいますか。',
            questionTextRuby:
                '6このりんごを2{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。{1人|ひとり}{分|ぶん}は{何こ|なんこ}ですか。',
            choices: ['2こ', '3こ', '4こ'],
            correct: 1,
            explanation: '6こを2人で同じ数ずつ分けるので、6 ÷ 2 = 3。1人分は3こです。',
            explanationRuby:
                '6こを2{人|にん}で{同じ数ずつ|おなじかずずつ}{分ける|わける}ので、6 ÷ 2 = 3。{1人|ひとり}{分|ぶん}は3こです。',
            formulaExplanationRuby:
                '6 ÷ 2 は、6このりんごを2{人|にん}で{同じ数ずつ|おなじかずずつ}{分ける|わける}{式|しき}です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['同じ数ずつ', '分ける', '1人分'],
            tags: ['equal-sharing', 'select_picture'],
            equationHint: '6 ÷ 2',
            visualHint: '6このりんごを、2人の箱に同じ数ずつ入れる。',
            pictureDescription: '2つの箱にりんごが3こずつ入っている図',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '6', 'groups': '2', 'each': '3'},
          ),
          _q(
            id: 7102,
            type: 'select_equation',
            school: '8このクッキーを4人で同じ数ずつ分けます。正しい式はどれですか。',
            easy: 'クッキー8こを4人に同じ数で分けます。どの式ですか。',
            questionTextRuby:
                '8このクッキーを4{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。{正しい|ただしい}{式|しき}はどれですか。',
            choices: ['8＋4', '8−4', '8×4', '8÷4'],
            correct: 3,
            explanation: '全部の8こを4人で分けるので、式は8 ÷ 4です。',
            explanationRuby:
                '{全部|ぜんぶ}の8こを4{人|にん}で{分ける|わける}ので、{式|しき}は8 ÷ 4です。',
            formulaExplanationRuby:
                '8 ÷ 4 は、8このクッキーを4{人|にん}で{同じ数ずつ|おなじかずずつ}{分ける|わける}{式|しき}です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['全部で', '同じ数ずつ', '分ける'],
            tags: ['equal-sharing', 'select_equation'],
            equationHint: '全部の数 ÷ 人数',
            visualHint: '',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '8', 'groups': '4', 'each': '2'},
          ),
          _q(
            id: 7103,
            type: 'number_input',
            school: '12このあめを3人で同じ数ずつ分けます。1人分は何こですか。',
            easy: 'あめが12こあります。3人に同じ数で分けます。1人は何こですか。',
            questionTextRuby:
                '12このあめを3{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。{1人|ひとり}{分|ぶん}は{何こ|なんこ}ですか。',
            choices: ['3', '4', '9', '15'],
            correct: 1,
            explanation: '12 ÷ 3 = 4。1人分は4こです。',
            explanationRuby: '12 ÷ 3 = 4。{1人|ひとり}{分|ぶん}は4こです。',
            formulaExplanationRuby:
                '12 ÷ 3 は、12このあめを3{人|にん}に{同じ数ずつ|おなじかずずつ}{分ける|わける}{式|しき}です。',
            languagePointRuby:
                '「{同じ数ずつ|おなじかずずつ}」は、1{人|にん}1{人|にん}が{同じ数|おなじかず}になるという{意味|いみ}です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['1人分', '同じ数ずつ'],
            tags: ['equal-sharing', 'number_input'],
            equationHint: '12 ÷ 3',
            thinkingHint: '3 × □ = 12 と考えます。',
            visualHint: '12このあめを3人の箱に同じ数ずつ入れる。',
            visualType: QuestionVisualType.divisionSharing,
            visualTitle: '12このあめを3人で分ける図',
            visualDescription: '3人のカードに、あめが4こずつ入ります。',
            itemLabel: 'あめ',
            itemEmoji: '🍬',
            itemUnit: 'こ',
            totalCount: 12,
            groupCount: 3,
            perGroupCount: 4,
          ),
        ],
      ),
      LessonStep(
        id: 'division-equal-share-practice',
        type: LessonStepType.independentPractice,
        title: '自分でとこう',
        questions: [
          _q(
            id: 7104,
            type: 'fill_blank',
            school: '15このカードを5人で同じ数ずつ分けます。式は 15 ÷ □ です。',
            easy: 'カード15こを5人で分けます。15 ÷ □ の□は何ですか。',
            questionTextRuby:
                '15このカードを5{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。{式|しき}は 15 ÷ □ です。',
            choices: ['3', '5', '10', '15'],
            correct: 1,
            explanation: '分ける人数は5人なので、式は15 ÷ 5です。',
            explanationRuby:
                '{分ける|わける}{人数|にんずう}は5{人|にん}なので、{式|しき}は15 ÷ 5です。',
            formulaExplanationRuby:
                '15このカードを5{人|にん}で{同じ数ずつ|おなじかずずつ}{分ける|わける}{式|しき}です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['式', '分ける'],
            tags: ['equal-sharing', 'fill_blank'],
            equationHint: '15 ÷ 5',
            visualHint: '',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '15', 'groups': '5', 'each': '3'},
          ),
          _q(
            id: 7105,
            type: 'select_equation',
            school: '20このみかんを4人で同じ数ずつ分けます。正しい式はどれですか。',
            easy: 'みかん20こを4人に同じ数で分けます。どの式ですか。',
            questionTextRuby:
                '20このみかんを4{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。{正しい|ただしい}{式|しき}はどれですか。',
            choices: ['20÷4', '20×4', '20＋4'],
            correct: 0,
            explanation: '全部の20こを4人で分けるので、式は20 ÷ 4です。',
            explanationRuby:
                '{全部|ぜんぶ}の20こを4{人|にん}で{分ける|わける}ので、{式|しき}は20 ÷ 4です。',
            formulaExplanationRuby:
                '20は{全部|ぜんぶ}の{数|かず}、4は{分ける|わける}{人数|にんずう}です。{全部|ぜんぶ}の{数|かず} ÷ {人数|にんずう}で{考えます|かんがえます}。',
            languagePointRuby:
                '「4{人|にん}で{分ける|わける}」は、{分ける|わける}{相手|あいて}が4{人|にん}いるという{意味|いみ}です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['式', '同じ数ずつ', '分ける'],
            tags: ['equal-sharing', 'select_equation'],
            equationHint: '20 ÷ 4',
            formulaExplanation: '20は全部の数、4は分ける人数です。全部の数 ÷ 人数で考えます。',
            languagePoint: '「4人で分ける」は、分ける相手が4人いるという意味です。',
          ),
          _q(
            id: 7106,
            type: 'word_problem',
            school: '6このいちごを3人で同じ数ずつ分けます。はじめにあるいちごは何こですか。',
            easy: 'いちごが6こあります。3人で分けます。全部で何こありますか。',
            questionTextRuby:
                '6このいちごを3{人|にん}で{同じ数ずつ|おなじかずずつ}{分けます|わけます}。はじめにあるいちごは{何こ|なんこ}ですか。',
            choices: ['6こ', '3こ', '2こ'],
            correct: 0,
            explanation: 'はじめにあるいちごは6こです。6こを3人で分けるので、式は6 ÷ 3です。',
            explanationRuby:
                'はじめにあるいちごは6こです。6こを3{人|にん}で{分ける|わける}ので、{式|しき}は6 ÷ 3です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['いちご', '全部の数', '何こ'],
            tags: ['equal-sharing', 'word_problem', 'quantity'],
            equationHint: '6 ÷ 3',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '6', 'groups': '3', 'each': '2'},
          ),
        ],
      ),
      LessonStep(
        id: 'division-equal-share-japanese',
        type: LessonStepType.independentPractice,
        title: '日本語だけで挑戦',
        questions: [
          _q(
            id: 7107,
            type: 'select_picture',
            school: '9このシールを3人で同じ数ずつ分けた図を選びましょう。',
            easy: 'シール9こを3人に同じ数で分けます。合う図はどれですか。',
            choices: ['1こずつの図', '3こずつの図', '9こずつの図'],
            correct: 1,
            explanation: '9 ÷ 3 = 3。3こずつの図が正しいです。',
            vocabulary: ['図', '同じ数ずつ'],
            tags: ['equal-sharing', 'select_picture'],
            equationHint: '9 ÷ 3',
            pictureDescription: '3人それぞれにシールが3こずつある図',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '9', 'groups': '3', 'each': '3'},
            choiceDiagramData: [
              {'total': '3', 'groups': '3', 'each': '1'},
              {'total': '9', 'groups': '3', 'each': '3'},
              {'total': '27', 'groups': '3', 'each': '9'},
            ],
          ),
          _q(
            id: 7108,
            type: 'story_to_equation',
            school: '18本のえんぴつを6人で同じ数ずつ分けます。1人分は何本ですか。',
            easy: 'えんぴつ18本を6人に同じ数で分けます。1人は何本ですか。',
            choices: ['2本', '3本', '6本', '12本'],
            correct: 1,
            explanation: '18 ÷ 6 = 3。1人分は3本です。',
            vocabulary: ['本', '1人分'],
            tags: ['equal-sharing', 'word_problem', 'unit'],
            equationHint: '18 ÷ 6',
            thinkingHint: '6 × □ = 18 と考えます。',
          ),
        ],
      ),
      _summary(
        id: 'division-equal-share-summary',
        school: '「全部の数」を「何人で分ける」かを見ると、1人分をわり算で求められます。',
        easy: '同じ数で分けて1人分を知りたいときは、わり算を使います。',
      ),
    ],
  ),
  Lesson(
    id: 8,
    levelId: 2,
    type: LessonType.practice,
    title: '何こずつ分けられるかな',
    description: '1人に何こずつ分けるかを決めて、何人に分けられるかを考えます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      _learn(
        id: 'division-measure-learn',
        title: '学習しよう',
        school: 'いちごが6こあります。1人に2こずつ分けると、何人に分けられますか。',
        easy: 'いちごが6こあります。1人に2こずつ分けると、何人分できますか。',
        native: {
          AppLanguage.portuguese:
              'Há 6 morangos. Se dermos 2 morangos para cada pessoa, para quantas pessoas dá para dividir?',
          AppLanguage.tagalog:
              'May 6 na strawberry. Kung tig-2 strawberry ang bawat tao, ilang tao ang mabibigyan?',
          AppLanguage.vietnamese:
              'Có 6 quả dâu. Nếu mỗi người nhận 2 quả, chia được cho bao nhiêu người?',
        },
      ),
      _learn(
        id: 'division-measure-words',
        title: 'ことばを知ろう',
        school: '大事な言葉は「何こずつ」「分ける」「何人に分けられる」「いくつ分」です。',
        easy: '「3こずつ分ける」は、1人に3こずつにすることです。「何人に」は、人の数を聞いています。',
      ),
      LessonStep(
        id: 'division-measure-guided',
        type: LessonStepType.guidedPractice,
        title: 'いっしょにとこう',
        questions: [
          _q(
            id: 7201,
            type: 'select_picture',
            school: '8このクッキーがあります。1人に2こずつ分けます。何人に分けられますか。',
            easy: 'クッキー8こを、1人に2こずつ分けます。何人分できますか。',
            questionTextRuby:
                '8このクッキーがあります。{1人|ひとり}に2こずつ{分けます|わけます}。{何人|なんにん}に{分けられます|わけられます}か。',
            choicesRuby: ['2{人|にん}', '4{人|にん}', '6{人|にん}'],
            choices: ['2人', '4人', '6人'],
            correct: 1,
            explanation: '8 ÷ 2 = 4。2こずつのまとまりが4つできるので、4人です。',
            explanationRuby:
                '8 ÷ 2 = 4。2こずつのまとまりが4つできるので、4{人|にん}です。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['何こずつ', '分ける', '何人'],
            tags: ['measurement-division', 'select_picture'],
            visualHint: '8このクッキーを2こずつの組にする。',
            pictureDescription: '2こずつの組が4つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '8', 'each': '2', 'groups': '4'},
          ),
          _q(
            id: 7202,
            type: 'select_equation',
            school: '12このあめを1人に3こずつ分けます。正しい式はどれですか。',
            easy: 'あめ12こを、1人に3こずつ分けます。どの式ですか。',
            questionTextRuby:
                '12このあめを{1人|ひとり}に3こずつ{分けます|わけます}。{正しい|ただしい}{式|しき}はどれですか。',
            choices: ['12÷3', '12×3', '12−3', '12＋3'],
            correct: 0,
            explanation: '全部の12こを、3こずつのまとまりにするので、12 ÷ 3です。',
            explanationRuby:
                '{全部|ぜんぶ}の12こを、3こずつのまとまりにするので、12 ÷ 3です。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['分ける', '何こずつ'],
            tags: ['measurement-division', 'select_equation'],
            equationHint: '全部の数 ÷ 1人分の数',
            visualHint: '12このあめを3こずつの組にする。',
            pictureDescription: '3こずつの組が4つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '12', 'each': '3', 'groups': '4'},
          ),
          _q(
            id: 7203,
            type: 'number_input',
            school: '15まいのカードを1人に5まいずつ分けます。何人に分けられますか。',
            easy: 'カード15まいを、1人に5まいずつ分けます。何人分できますか。',
            questionTextRuby:
                '15まいのカードを{1人|ひとり}に5まいずつ{分けます|わけます}。{何人|なんにん}に{分けられます|わけられます}か。',
            choices: ['3', '5', '10', '20'],
            correct: 0,
            explanation: '15 ÷ 5 = 3。3人に分けられます。',
            explanationRuby:
                '15 ÷ 5 = 3。3{人|にん}に{分けられます|わけられます}。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['まい', '何人に分けられる'],
            tags: ['measurement-division', 'number_input', 'unit'],
            equationHint: '15 ÷ 5',
            thinkingHint: '5 × □ = 15 と考えます。',
            visualHint: '15まいのカードを5まいずつの組にする。',
            pictureDescription: '5まいずつの組が3つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '15', 'each': '5', 'groups': '3'},
            itemUnit: 'まい',
          ),
        ],
      ),
      LessonStep(
        id: 'division-measure-practice',
        type: LessonStepType.independentPractice,
        title: '自分でとこう',
        questions: [
          _q(
            id: 7204,
            type: 'fill_blank',
            school: '18このビー玉を1人に6こずつ分けます。式は 18 ÷ □ です。',
            easy: 'ビー玉18こを、1人に6こずつ分けます。18 ÷ □ の□は何ですか。',
            questionTextRuby:
                '18この{ビー玉|びーだま}を{1人|ひとり}に6こずつ{分けます|わけます}。{式|しき}は 18 ÷ □ です。',
            choices: ['3', '6', '12', '18'],
            correct: 1,
            explanation: '1人に6こずつ分けるので、式は18 ÷ 6です。',
            explanationRuby:
                '{1人|ひとり}に6こずつ{分ける|わける}ので、{式|しき}は18 ÷ 6です。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['ずつ', '分ける'],
            tags: ['measurement-division', 'fill_blank'],
            equationHint: '18 ÷ 6',
            visualHint: '18このビー玉を6こずつの組にする。',
            pictureDescription: '6こずつの組が3つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '18', 'each': '6', 'groups': '3'},
          ),
          _q(
            id: 7205,
            type: 'select_equation',
            school: '24このシールを1人に4こずつ分けます。何人に分けられますか。正しい式はどれですか。',
            easy: 'シール24こを、1人に4こずつ分けます。どの式ですか。',
            questionTextRuby:
                '24このシールを{1人|ひとり}に4こずつ{分けます|わけます}。{何人|なんにん}に{分けられます|わけられます}か。{正しい|ただしい}{式|しき}はどれですか。',
            choices: ['24÷4', '24÷6', '24×4'],
            correct: 0,
            explanation: '全部の24こを、1人分の4こで分けるので、式は24 ÷ 4です。',
            explanationRuby:
                '{全部|ぜんぶ}の24こを、{1人|ひとり}{分|ぶん}の4こで{分ける|わける}ので、{式|しき}は24 ÷ 4です。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['何人に分けられる', '式'],
            tags: ['measurement-division', 'select_equation'],
            equationHint: '24 ÷ 4',
            formulaExplanation: '24は全部の数、4は1人分の数です。全部の数 ÷ 1人分の数で考えます。',
            languagePoint: '「1人に4こずつ」は、1人分の数が4こだという意味です。',
            visualHint: '24このシールを4こずつの組にする。',
            pictureDescription: '4こずつの組が6つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '24', 'each': '4', 'groups': '6'},
          ),
          _q(
            id: 7206,
            type: 'word_problem',
            school: '6このいちごを1人に2こずつ分けます。何人に分けられますか。',
            easy: 'いちご6こを、1人に2こずつ分けます。何人分できますか。',
            questionTextRuby:
                '6このいちごを{1人|ひとり}に2こずつ{分けます|わけます}。{何人|なんにん}に{分けられます|わけられます}か。',
            choicesRuby: ['3{人|にん}', '2{人|にん}', '6{人|にん}'],
            choices: ['3人', '2人', '6人'],
            correct: 0,
            explanation: '6こを2こずつのまとまりにすると、3つのまとまりができます。だから、3人に分けられます。',
            explanationRuby:
                '6こを2こずつのまとまりにすると、3つのまとまりができます。だから、3{人|にん}に{分けられます|わけられます}。',
            vocabularyEntries: measureDivisionVocabularyEntries,
            vocabulary: ['いちご', '何人'],
            tags: [
              'measurement-division',
              'word_problem',
              'count_groups',
            ],
            equationHint: '6 ÷ 2 = 3',
            visualHint: '6こを2こずつの組にする。',
            pictureDescription: '2こずつの組が3つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '6', 'each': '2', 'groups': '3'},
          ),
        ],
      ),
      LessonStep(
        id: 'division-measure-japanese',
        type: LessonStepType.independentPractice,
        title: '日本語だけで挑戦',
        questions: [
          _q(
            id: 7207,
            type: 'select_picture',
            school: '10このあめを1人に2こずつ分けた図を選びましょう。',
            easy: 'あめ10こを、1人に2こずつ分けます。合う図はどれですか。',
            choices: ['2こずつ5組の図', '5こずつ2組の図', '10こずつ1組の図'],
            correct: 0,
            explanation: '10 ÷ 2 = 5。2こずつの組が5つある図です。',
            vocabulary: ['図', '2こずつ'],
            tags: ['measurement-division', 'select_picture'],
            equationHint: '10 ÷ 2',
            pictureDescription: '2こずつの組が5つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '10', 'each': '2', 'groups': '5'},
            choiceDiagramData: [
              {
                'total': '10',
                'each': '2',
                'groups': '5',
                'labelSuffix': '組目',
              },
              {
                'total': '10',
                'each': '5',
                'groups': '2',
                'labelSuffix': '組目',
              },
              {
                'total': '10',
                'each': '10',
                'groups': '1',
                'labelSuffix': '組目',
              },
            ],
          ),
          _q(
            id: 7208,
            type: 'story_to_equation',
            school: '21本のえんぴつを1人に3本ずつ分けます。何人に分けられますか。',
            easy: 'えんぴつ21本を、1人に3本ずつ分けます。何人分できますか。',
            choices: ['7人', '7本', '18人', '24人'],
            correct: 0,
            explanation: '21 ÷ 3 = 7。答えの単位は人です。',
            vocabulary: ['本', '何人'],
            tags: ['measurement-division', 'word_problem', 'unit'],
            equationHint: '21 ÷ 3',
            thinkingHint: '3 × □ = 21 と考えます。',
            visualHint: '21本のえんぴつを3本ずつの組にする。',
            pictureDescription: '3本ずつの組が7つある図',
            diagramType: 'groups_of',
            diagramData: {'total': '21', 'each': '3', 'groups': '7'},
            itemUnit: '本',
          ),
        ],
      ),
      _summary(
        id: 'division-measure-summary',
        school: '「1人に何こずつ分ける」かが分かっているときは、何人に分けられるかをわり算で求められます。',
        easy: '同じ数のまとまりがいくつできるかを考えると、人数が分かります。',
      ),
    ],
  ),
  Lesson(
    id: 17,
    levelId: 2,
    type: LessonType.practice,
    title: 'かけ算からわり算を考える',
    description: 'わり算の答えを、かけ算を使って見つけます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      _learn(
        id: 'division-multiplication-link-learn',
        title: '学習しよう',
        school: 'かけ算を使って、わり算の答えを見つけよう。',
        easy: 'わり算とかけ算のつながりを、図と式で見ます。',
        native: {
          AppLanguage.portuguese:
              'Vamos usar a multiplicação para encontrar a resposta da divisão.',
          AppLanguage.tagalog:
              'Gagamit tayo ng multiplication para hanapin ang sagot sa division.',
          AppLanguage.vietnamese:
              'Dùng phép nhân để tìm đáp án của phép chia.',
        },
      ),
      LessonStep(
        id: 'division-multiplication-link-guided',
        type: LessonStepType.guidedPractice,
        title: 'いっしょにとこう',
        questions: [
          _q(
            id: 1701,
            type: 'multiplication_check',
            school: '24 ÷ 6 = □。答えを見つけるために使うかけ算はどれですか。',
            easy: '24 ÷ 6 の答えを、かけ算で見つけます。どのかけ算を使いますか。',
            questionTextRuby:
                '24 ÷ 6 = □。{答え|こたえ}を{見つける|みつける}ために{使う|つかう}かけ{算|ざん}はどれですか。',
            choices: ['6 × 3 = 18', '6 × 4 = 24', '6 × 5 = 30'],
            correct: 1,
            explanation: '6 × 4 = 24だから、24 ÷ 6 = 4です。',
            explanationRuby:
                '6 × 4 = 24だから、24 ÷ 6 = 4です。',
            formulaExplanation: '24になるかけ算を探します。6に4をかけると24になります。',
            formulaExplanationRuby:
                '24になるかけ{算|ざん}を{探します|さがします}。6に4をかけると24になります。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['答え', 'かけ算', '使う'],
            tags: ['multiplication_connection', 'select_equation'],
            equationHint: '6 × □ = 24',
            thinkingHint: '24になるかけ算を探してみよう。',
          ),
          _q(
            id: 1702,
            type: 'fill_blank',
            school: '18 ÷ 3 = □。3 × □ = 18。□に入る数はどれですか。',
            easy: '18 ÷ 3 と 3 × □ = 18 を見ます。□に入る数はどれですか。',
            questionTextRuby:
                '18 ÷ 3 = □。3 × □ = 18。□に{入る|はいる}{数|かず}はどれですか。',
            choices: ['4', '5', '6', '7'],
            correct: 2,
            explanation: '□には同じ6が入ります。18 ÷ 3 = 6、3 × 6 = 18です。',
            explanationRuby:
                '□には{同じ|おな}じ6が{入ります|はいります}。18 ÷ 3 = 6、3 × 6 = 18です。',
            formulaExplanation: 'わり算の答えの6は、かけ算の□にも入ります。',
            formulaExplanationRuby:
                'わり{算|ざん}の{答え|こたえ}の6は、かけ{算|ざん}の□にも{入ります|はいります}。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['数', '答え', 'かけ算'],
            tags: ['multiplication_connection', 'fill_blank'],
            equationHint: '3 × □ = 18',
          ),
        ],
      ),
      LessonStep(
        id: 'division-multiplication-link-practice',
        type: LessonStepType.independentPractice,
        title: '自分でとこう',
        questions: [
          _q(
            id: 1703,
            type: 'story_to_equation',
            school: 'りんごが21こあります。7人に同じ数ずつ分けます。1人分は何こですか。',
            easy: 'りんご21こを7人で同じ数ずつ分けます。1人分は何こですか。',
            questionTextRuby:
                'りんごが21こあります。7{人|にん}に{同|おな}じ{数|かず}ずつ{分けます|わけます}。{1人|ひとり}{分|ぶん}は{何こ|なんこ}ですか。',
            choices: ['2こ', '3こ', '7こ', '14こ'],
            correct: 1,
            explanation: '7 × 3 = 21だから、21 ÷ 7 = 3です。1人分は3こです。',
            explanationRuby:
                '7 × 3 = 21だから、21 ÷ 7 = 3です。{1人|ひとり}{分|ぶん}は3こです。',
            formulaExplanation: '21になる7のかけ算を探します。7 × 3 = 21です。',
            formulaExplanationRuby:
                '21になる7のかけ{算|ざん}を{探します|さがします}。7 × 3 = 21です。',
            vocabularyEntries: _divisionSharingVocabulary,
            vocabulary: ['りんご', '同じ数ずつ', '1人分'],
            tags: ['multiplication_connection', 'word_problem'],
            equationHint: '21 ÷ 7 = □',
            thinkingHint: '7 × □ = 21',
            diagramType: 'equal_share_boxes',
            diagramData: {'total': '21', 'groups': '7', 'each': '3'},
            itemEmoji: '🍎',
            itemUnit: 'こ',
          ),
        ],
      ),
      LessonStep(
        id: 'division-multiplication-link-japanese',
        type: LessonStepType.independentPractice,
        title: '日本語だけで挑戦',
        questions: [
          _q(
            id: 1704,
            type: 'multiplication_check',
            school: '36 ÷ 6 = □。答えを見つけるために使うかけ算はどれですか。',
            easy: '36 ÷ 6 の答えを、かけ算で見つけます。',
            choices: ['6 × 5 = 30', '6 × 6 = 36', '6 × 7 = 42'],
            correct: 1,
            explanation: '6 × 6 = 36だから、36 ÷ 6 = 6です。',
            vocabulary: ['かけ算', '答え'],
            tags: ['multiplication_connection', 'japanese_only'],
            equationHint: '6 × □ = 36',
          ),
          _q(
            id: 1705,
            type: 'fill_blank',
            school: '28 ÷ 4 = □。4 × □ = 28。□に入る数はどれですか。',
            easy: '28 ÷ 4 と 4 × □ = 28 を見ます。',
            choices: ['5', '6', '7', '8'],
            correct: 2,
            explanation: '4 × 7 = 28だから、28 ÷ 4 = 7です。',
            vocabulary: ['□', 'かけ算'],
            tags: ['multiplication_connection', 'japanese_only'],
            equationHint: '4 × □ = 28',
          ),
        ],
      ),
      _summary(
        id: 'division-multiplication-link-summary',
        school: 'わられる数になるかけ算を探すと、わり算の答えが分かります。',
        easy: 'かけ算を使うと、わり算の答えを見つけられます。',
      ),
    ],
  ),
  Lesson(
    id: 9,
    levelId: 2,
    type: LessonType.practice,
    title: '0や1を使ったわり算',
    description: '1でわる、0をわる、0ではわれない場面を見て考えます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      _learn(
        id: 'division-zero-one-learn',
        title: '学習しよう',
        school:
            '1でわると答えはもとの数になります。0を人数でわると答えは0になります。0ではわることはできません。',
        easy: '1人で分ける、0こを分ける、0人で分ける場面を見て考えます。',
      ),
      _learn(
        id: 'division-multiplication-words',
        title: 'ことばを知ろう',
        school: '大事な言葉は「1でわる」「0をわる」「0ではわれない」です。',
        easy: '「6 ÷ 1」は6こを1人で分けることです。「0 ÷ 3」は0こを3人で分けることです。「6 ÷ 0」は分ける人がいないのでできません。',
      ),
      LessonStep(
        id: 'division-multiplication-guided',
        type: LessonStepType.guidedPractice,
        title: 'いっしょにとこう',
        questions: [
          _q(
            id: 7301,
            type: 'fill_blank',
            school: '0 ÷ 3 = □。□に入る数は何ですか。',
            easy: '0こを3人で分けます。1人分は何こですか。',
            choices: ['0', '1', '3', '6'],
            correct: 0,
            explanation: '0こを分けるので、1人分も0こです。0 ÷ 3 = 0 です。',
            vocabulary: ['0', '分ける'],
            tags: ['zero_division_result', 'fill_blank'],
            equationHint: '0 ÷ 3 = 0',
          ),
          _q(
            id: 7302,
            type: 'number_input',
            school: '6 ÷ 1 = □。□に入る数は何ですか。',
            easy: '6こを1人で分けます。1人分は何こですか。',
            choices: ['1', '5', '6', '7'],
            correct: 2,
            explanation: '6こを1人で分けるので、全部その人の分です。6 ÷ 1 = 6 です。',
            vocabulary: ['1でわる', '1人分'],
            tags: ['divide_by_one', 'number_input'],
            equationHint: '6 ÷ 1 = 6',
          ),
          _q(
            id: 7303,
            type: 'number_input',
            school: '6 ÷ 6 = □。□に入る数は何ですか。',
            easy: '6こを6人で分けます。1人分は何こですか。',
            choices: ['0', '1', '6', '12'],
            correct: 1,
            explanation: '6こを6人で同じ数ずつ分けると、1人分は1こです。6 ÷ 6 = 1 です。',
            vocabulary: ['同じ数でわる', '1人分'],
            tags: ['divide_by_same_number', 'number_input'],
            equationHint: '6 ÷ 6 = 1',
          ),
        ],
      ),
      LessonStep(
        id: 'division-multiplication-practice',
        type: LessonStepType.independentPractice,
        title: '自分でとこう',
        questions: [
          _q(
            id: 7304,
            type: 'select_equation',
            school: '0このあめを4人で同じ数ずつ分けます。正しい式はどれですか。',
            easy: 'あめが0こです。4人で分けます。どの式ですか。',
            choices: ['0÷4', '4÷0', '4÷4'],
            correct: 0,
            explanation: '全部の数が0こなので、式は0 ÷ 4です。0でわる式は選びません。',
            vocabulary: ['0', '正しい式'],
            tags: ['zero_division_result', 'select_equation'],
            equationHint: '0 ÷ 4',
          ),
          _q(
            id: 7305,
            type: 'fill_blank',
            school: '9 ÷ 1 = □。□に入る数は何ですか。',
            easy: '9こを1人で分けます。1人分は何こですか。',
            choices: ['1', '8', '9', '10'],
            correct: 2,
            explanation: '1人で分けるので、9こ全部がその人の分です。9 ÷ 1 = 9 です。',
            vocabulary: ['1でわる'],
            tags: ['divide_by_one', 'fill_blank'],
            equationHint: '9 ÷ 1 = 9',
          ),
          _q(
            id: 7306,
            type: 'select_equation',
            school: '8 ÷ 8 = □。□に入る数はどれですか。',
            easy: '8こを8人で分けます。1人分は何こですか。',
            choices: ['0', '1', '8', '16'],
            correct: 1,
            explanation: '8こを8人で分けると、1人分は1こです。8 ÷ 8 = 1 です。',
            vocabulary: ['同じ数でわる'],
            tags: ['divide_by_same_number', 'select_equation'],
            equationHint: '8 ÷ 8 = 1',
          ),
        ],
      ),
      LessonStep(
        id: 'division-multiplication-japanese',
        type: LessonStepType.independentPractice,
        title: '日本語だけで挑戦',
        questions: [
          _q(
            id: 7307,
            type: 'number_input',
            school: '7 ÷ 7 = □',
            easy: '7を7でわります。答えは何ですか。',
            choices: ['0', '1', '7', '14'],
            correct: 1,
            explanation: '同じ数でわると、答えは1です。7 ÷ 7 = 1 です。',
            vocabulary: ['わり算'],
            tags: ['calculation', 'divide_by_same_number'],
            equationHint: '7 ÷ 7 = 1',
          ),
          _q(
            id: 7308,
            type: 'select_word_meaning',
            school: '6 ÷ 0 について、正しいものはどれですか。',
            easy: '6を0でわることについて、正しいものを選びます。',
            choices: ['6', '0', '答えはありません'],
            correct: 2,
            explanation: '0人には分けられないので、6 ÷ 0 の答えはありません。',
            vocabulary: ['0ではわれない'],
            tags: ['divide_by_zero', 'rule_check'],
            equationHint: '6 ÷ 0',
          ),
        ],
      ),
      _summary(
        id: 'division-multiplication-summary',
        school: '1でわると答えはもとの数、0を人数でわると答えは0、0ではわることはできません。',
        easy: 'わり算は、分けるものと分ける人を見て考えます。',
      ),
    ],
  ),
  Lesson(
    id: 10,
    levelId: 2,
    type: LessonType.practice,
    title: '文章を読んで式を作る',
    description: '文章題から、全部の数・分ける数・聞かれていることを見つけます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      _learn(
        id: 'division-story-learn',
        title: '学習しよう',
        school:
            '文章題では、まず「全部の数」を見つけます。次に、「何人で分ける」か、または「何こずつ分ける」かを見つけます。最後に、わり算の式にします。',
        easy: '文章を読むときは、全部の数、分ける数、聞いていることを順番に見ます。',
      ),
      _learn(
        id: 'division-story-words',
        title: 'ことばを知ろう',
        school: '大事な言葉は「全部で」「同じ数ずつ」「何人で」「何こずつ」「1人分」「何人に」です。',
        easy: '「1人分」は答えが「こ」や「本」になりやすく、「何人に」は答えが「人」になります。',
      ),
      LessonStep(
        id: 'division-story-guided',
        type: LessonStepType.guidedPractice,
        title: 'いっしょにとこう',
        questions: [
          _q(
            id: 7401,
            type: 'select_word_meaning',
            school: '「12このあめを3人で同じ数ずつ分けます。」全部の数はどれですか。',
            easy: 'あめは全部で何こありますか。',
            choices: ['12こ', '3人', '同じ数ずつ'],
            correct: 0,
            explanation: '全部の数は、はじめにある12こです。',
            vocabulary: ['全部の数'],
            tags: ['reading', 'keyword', 'select_word_meaning'],
          ),
          _q(
            id: 7402,
            type: 'select_word_meaning',
            school: '「18本のえんぴつを6人で分けます。」分ける人数はどれですか。',
            easy: '何人で分けますか。',
            choices: ['18本', '6人', 'えんぴつ'],
            correct: 1,
            explanation: '分ける人数は6人です。',
            vocabulary: ['分ける人数'],
            tags: ['reading', 'keyword', 'select_word_meaning'],
          ),
          _q(
            id: 7403,
            type: 'select_equation',
            school: '20このみかんを5人で同じ数ずつ分けます。正しい式はどれですか。',
            easy: 'みかん20こを5人で分けます。どの式ですか。',
            choices: ['20÷5', '20×5', '20＋5'],
            correct: 0,
            explanation: '全部の20こを5人で分けるので、20 ÷ 5です。',
            vocabulary: ['正しい式'],
            tags: ['story_to_equation', 'select_equation'],
            equationHint: '20 ÷ 5',
          ),
          _q(
            id: 7404,
            type: 'story_to_equation',
            school: '24まいの色紙を8人で同じ数ずつ分けます。式を書きましょう。',
            easy: '色紙24まいを8人で分けます。式はどれですか。',
            choices: ['24÷8', '24×8', '24−8'],
            correct: 0,
            explanation: '全部の24まいを8人で分けるので、式は24 ÷ 8です。',
            vocabulary: ['式を書く'],
            tags: ['story_to_equation', 'select_equation'],
            equationHint: '24 ÷ 8',
          ),
        ],
      ),
      LessonStep(
        id: 'division-story-practice',
        type: LessonStepType.independentPractice,
        title: '自分でとこう',
        questions: [
          _q(
            id: 7405,
            type: 'unit_choice',
            school: '27このビー玉を9人で同じ数ずつ分けます。1人分は何こですか。',
            easy: 'ビー玉27こを9人に同じ数で分けます。1人は何こですか。',
            choices: ['こ', '人', 'まい'],
            correct: 0,
            explanation: '聞いているのは1人分のビー玉の数です。ビー玉を数えるので、答えの単位は「こ」です。',
            vocabulary: ['1人分', '単位'],
            tags: ['equal-sharing', 'unit_choice'],
            equationHint: '27 ÷ 9',
            formulaExplanation: '27は全部の数、9は分ける人数です。式は27 ÷ 9です。',
            languagePoint: '「何こですか」は、答えの単位が「こ」になる合図です。',
          ),
          _q(
            id: 7406,
            type: 'select_word_meaning',
            school: '「12こを3人で分ける」と「12こを3こずつ分ける」は、聞いていることが同じですか。',
            easy: '1人分を聞く問題と、何人分かを聞く問題は同じですか。',
            choices: ['同じ', '違う'],
            correct: 1,
            explanation: '「3人で分ける」は1人分、「3こずつ分ける」は何人分かを聞いています。',
            vocabulary: ['聞いていること', '違う'],
            tags: ['reading', 'equal-sharing', 'measurement-division'],
          ),
          _q(
            id: 7407,
            type: 'select_word_meaning',
            school: '16このクッキーを1人に4こずつ分けます。これはどちらですか。',
            easy: '1人に4こずつ分けるとき、何を求めますか。',
            choices: ['1人分を求める', '何人分かを求める'],
            correct: 1,
            explanation: '1人に4こずつ分けるので、何人に分けられるかを求めます。',
            vocabulary: ['何人分'],
            tags: ['reading', 'measurement-division'],
          ),
        ],
      ),
      LessonStep(
        id: 'division-story-japanese',
        type: LessonStepType.independentPractice,
        title: '日本語だけで挑戦',
        questions: [
          _q(
            id: 7408,
            type: 'select_word_meaning',
            school: '30このシールを1人に5こずつ分けます。何を聞いていますか。',
            easy: 'シール30こを、1人に5こずつ分けます。何を答えますか。',
            choices: ['何人に分けられるか', '1人分は何こか', '全部で何こか'],
            correct: 0,
            explanation: '1人に5こずつ分けるので、5こずつのまとまりが何人分できるかを聞いています。',
            vocabulary: ['何人に分けられる'],
            tags: ['measurement-division', 'reading'],
            equationHint: '30 ÷ 5',
            languagePoint: '「何人に」は、人の数を答える合図です。',
          ),
          _q(
            id: 7409,
            type: 'select_equation',
            school: '28このあめを4人で同じ数ずつ分けます。1人分は何こですか。',
            easy: 'あめ28こを4人に同じ数で分けます。1人は何こですか。',
            choices: ['28÷4', '28÷7', '28−4'],
            correct: 0,
            explanation: '全部の28こを4人で分けるので、式は28 ÷ 4です。',
            vocabulary: ['1人分', '式'],
            tags: ['equal-sharing', 'select_equation'],
            equationHint: '28 ÷ 4',
            formulaExplanation: '28は全部の数、4は分ける人数です。',
            languagePoint: '「1人分」は、1人がもらう数を聞く言葉です。',
          ),
          _q(
            id: 7410,
            type: 'select_equation',
            school: '「18 ÷ 3 = 6」に合う文章を選びましょう。',
            easy: '18 ÷ 3 = 6 と同じ意味の文章はどれですか。',
            choices: ['18こを3人で分ける', '18こを3こずつ分ける', '3こを18人で分ける'],
            correct: 0,
            explanation: '18こを3人で分けると、1人分は6こです。',
            vocabulary: ['合う文章'],
            tags: ['reading', 'story_to_equation', 'select_equation'],
            equationHint: '18 ÷ 3 = 6',
          ),
        ],
      ),
      _summary(
        id: 'division-story-summary',
        school: '文章題では、全部の数、分ける数、聞いていることを見つけると、式を作れます。',
        easy: '「1人分」か「何人に」かを見ると、答えの単位も分かりやすくなります。',
      ),
    ],
  ),
  Lesson(
    id: 11,
    levelId: 2,
    type: LessonType.practice,
    title: 'たしかめ問題',
    description: 'これまでのわり算を、日本語だけでたしかめます。',
    completed: false,
    locked: true,
    stars: 0,
    maxStars: 3,
    questions: const [],
    steps: [
      LessonStep(
        id: 'division-check-japanese-calculation',
        type: LessonStepType.independentPractice,
        title: 'たしかめ問題',
        questions: [
          _q(
            id: 7501,
            type: 'number_input',
            school: '16 ÷ 4 = □',
            easy: '16を4でわります。答えは何ですか。',
            choices: ['3', '4', '12', '20'],
            correct: 1,
            explanation: '4 × 4 = 16 なので、16 ÷ 4 = 4です。',
            vocabulary: ['計算'],
            tags: ['calculation'],
            equationHint: '4 × □ = 16',
          ),
          _q(
            id: 7504,
            type: 'story_to_equation',
            school: '24このクッキーを6人で同じ数ずつ分けます。1人分は何こですか。',
            easy: 'クッキー24こを6人に同じ数で分けます。1人は何こですか。',
            choices: ['4こ', '4人', '18こ', '30こ'],
            correct: 0,
            explanation: '24 ÷ 6 = 4。1人分は4こです。',
            vocabulary: ['1人分', 'こ'],
            tags: ['equal-sharing', 'word_problem', 'unit'],
            equationHint: '24 ÷ 6',
          ),
          _q(
            id: 7502,
            type: 'number_input',
            school: '21 ÷ 7 = □',
            easy: '21を7でわります。答えは何ですか。',
            choices: ['3', '7', '14', '28'],
            correct: 0,
            explanation: '7 × 3 = 21 なので、21 ÷ 7 = 3です。',
            vocabulary: ['計算'],
            tags: ['calculation'],
            equationHint: '7 × □ = 21',
          ),
          _q(
            id: 7503,
            type: 'number_input',
            school: '36 ÷ 6 = □',
            easy: '36を6でわります。答えは何ですか。',
            choices: ['5', '6', '30', '42'],
            correct: 1,
            explanation: '6 × 6 = 36 なので、36 ÷ 6 = 6です。',
            vocabulary: ['計算'],
            tags: ['calculation'],
            equationHint: '6 × □ = 36',
          ),
        ],
      ),
      LessonStep(
        id: 'division-check-japanese-word-problems',
        type: LessonStepType.independentPractice,
        title: 'たしかめ問題',
        questions: [
          _q(
            id: 7505,
            type: 'story_to_equation',
            school: '24このクッキーを1人に6こずつ分けます。何人に分けられますか。',
            easy: 'クッキー24こを、1人に6こずつ分けます。何人ですか。',
            choices: ['4人', '4こ', '18人', '30人'],
            correct: 0,
            explanation: '24 ÷ 6 = 4。聞いているのは人数なので4人です。',
            vocabulary: ['何人に分けられる'],
            tags: ['measurement-division', 'word_problem', 'unit'],
            equationHint: '24 ÷ 6',
          ),
          _q(
            id: 7507,
            type: 'unit_choice',
            school: '30このあめを1人に5こずつ分けます。答えの単位はどれですか。',
            easy: '何人に分けられるかを聞いています。答えの単位はどれですか。',
            choices: ['こ', '人', '本'],
            correct: 1,
            explanation: '「何人に分けられますか」と聞いているので、単位は人です。',
            vocabulary: ['単位', '何人'],
            tags: ['measurement-division', 'unit_choice', 'unit'],
          ),
          _q(
            id: 7506,
            type: 'select_equation',
            school: '35本のえんぴつを5人で同じ数ずつ分けます。式はどれですか。',
            easy: 'えんぴつ35本を5人で分けます。どの式ですか。',
            choices: ['35÷5', '35×5', '35−5'],
            correct: 0,
            explanation: '全部の35本を5人で分けるので、35 ÷ 5です。',
            vocabulary: ['式'],
            tags: ['equal-sharing', 'select_equation'],
            equationHint: '35 ÷ 5',
          ),
          _q(
            id: 7508,
            type: 'unit_choice',
            school: '30このあめを5人で同じ数ずつ分けます。答えの単位はどれですか。',
            easy: '1人分のあめの数を聞いています。答えの単位はどれですか。',
            choices: ['こ', '人', 'cm'],
            correct: 0,
            explanation: 'あめの数を聞いているので、単位は「こ」です。',
            vocabulary: ['単位', '1人分'],
            tags: ['equal-sharing', 'unit_choice', 'unit'],
          ),
        ],
      ),
      LessonStep(
        id: 'division-check-japanese-final',
        type: LessonStepType.independentPractice,
        title: 'たしかめ問題',
        questions: [
          _q(
            id: 7509,
            type: 'story_to_equation',
            school: '42まいのカードを7人で同じ数ずつ分けます。1人分は何まいですか。',
            easy: 'カード42まいを7人に同じ数で分けます。1人は何まいですか。',
            choices: ['6まい', '6人', '35まい', '49まい'],
            correct: 0,
            explanation: '42 ÷ 7 = 6。1人分は6まいです。',
            vocabulary: ['まい', '1人分'],
            tags: ['equal-sharing', 'word_problem', 'unit'],
            equationHint: '42 ÷ 7',
          ),
          _q(
            id: 7511,
            type: 'multiplication_check',
            school: '48 ÷ 8 の答えを、8×□＝48 で考えます。□はいくつですか。',
            easy: '8に何をかけると48ですか。',
            choices: ['5', '6', '8', '40'],
            correct: 1,
            explanation: '8 × 6 = 48 なので、48 ÷ 8 = 6です。',
            vocabulary: ['かけ算で確認'],
            tags: ['multiplication_check'],
            equationHint: '8 × □ = 48',
          ),
          _q(
            id: 7510,
            type: 'story_to_equation',
            school: '42まいのカードを1人に7まいずつ分けます。何人に分けられますか。',
            easy: 'カード42まいを、1人に7まいずつ分けます。何人ですか。',
            choices: ['6人', '6まい', '35人', '49人'],
            correct: 0,
            explanation: '42 ÷ 7 = 6。答えは6人です。',
            vocabulary: ['何人に分けられる'],
            tags: ['measurement-division', 'word_problem', 'unit'],
            equationHint: '42 ÷ 7',
          ),
          _q(
            id: 7513,
            type: 'word_problem',
            school:
                '木がまっすぐに6本ならんでいます。となりの木との間はどこも同じ長さです。はじめの木から最後の木まで30mです。となりの木との間は何mですか。',
            easy: '木が6本あります。木と木の間は同じ長さです。はじめから最後まで30mです。1つの間は何mですか。',
            questionTextRuby:
                '{木|き}がまっすぐに6{本|ぽん}ならんでいます。となりの{木|き}との{間|あいだ}はどこも{同じ|おなじ}{長さ|ながさ}です。はじめの{木|き}から{最後|さいご}の{木|き}まで30mです。となりの{木|き}との{間|あいだ}は{何|なん}mですか。',
            choices: ['5m', '6m', '30m', '36m'],
            correct: 1,
            correctAnswerText: '6m',
            correctAnswerTextRuby: '6m',
            explanation:
                '木が6本ならぶと、木と木の間は5つできます。30mを5つの間で同じ長さに分けるので、30 ÷ 5 = 6。1つの間は6mです。',
            explanationRuby:
                '{木|き}が6{本|ぽん}ならぶと、{木|き}と{木|き}の{間|あいだ}は5つできます。30mを5つの{間|あいだ}で{同じ|おなじ}{長さ|ながさ}に{分ける|わける}ので、30 ÷ 5 = 6。1つの{間|あいだ}は6mです。',
            formulaExplanation:
                '6本の木には、間が5つあります。全部の長さ30m ÷ 間の数5 = 1つ分の長さ6mです。',
            languagePoint: '「木が6本」でも、「間」は5つです。数えるものが木なのか、間なのかを見分けます。',
            vocabulary: ['間', '同じ長さ', '最後'],
            tags: ['division', 'word_problem', 'interval', 'number_line'],
            equationHint: '30 ÷ 5',
            thinkingHint: '6本の木をかくと、間は5つです。',
            visualHint: '🌳──🌳──🌳──🌳──🌳──🌳。間は5つ、全部で30m。',
            visualType: QuestionVisualType.numberLine,
            visualTitle: '木と木の間を数える図',
            visualDescription: '6本の木には間が5つあります。30mを5つに分けると、1つ分は6mです。',
            itemLabel: '木',
            itemEmoji: '🌳',
            itemUnit: '本',
            totalCount: 6,
            groupCount: 5,
            perGroupCount: 6,
            diagramType: 'interval_line',
            diagramData: {
              'points': '6',
              'segments': '5',
              'totalLabel': '全部で30m',
              'segmentLabel': '6m',
              'pointEmoji': '🌳',
              'unknownLabel': '？m',
            },
          ),
        ],
      ),
      _summary(
        id: 'division-challenge-summary',
        school: 'あまりのないわり算では、全部の数を同じ数ずつ分けたり、1人分を決めて分けたりできます。',
        easy: '文章を読んで、何を聞いているかを見ると、式と単位を選びやすくなります。',
      ),
    ],
  ),
];

LessonStep _learn({
  required String id,
  required String title,
  required String school,
  required String easy,
  Map<AppLanguage, String>? native,
}) {
  return LessonStep(
    id: id,
    type: LessonStepType.learn,
    title: title,
    explanationSchoolJa: school,
    explanationEasyJa: easy,
    explanationNative: native ?? _nativeText(easy),
  );
}

LessonStep _summary({
  required String id,
  required String school,
  required String easy,
}) {
  return LessonStep(
    id: id,
    type: LessonStepType.summary,
    title: 'まとめ',
    explanationSchoolJa: school,
    explanationEasyJa: easy,
    explanationNative: _nativeText(easy),
  );
}

Question _q({
  required int id,
  required String type,
  required String school,
  required String easy,
  required List<String> choices,
  required int correct,
  required String explanation,
  required List<String> vocabulary,
  required List<String> tags,
  String correctAnswerText = '',
  String correctAnswerTextRuby = '',
  String questionTextRuby = '',
  List<String> choicesRuby = const [],
  String formulaExplanation = '',
  String formulaExplanationRuby = '',
  String languagePoint = '',
  String languagePointRuby = '',
  String explanationRuby = '',
  List<VocabularyEntry> vocabularyEntries = const [],
  QuestionVisualType visualType = QuestionVisualType.none,
  String visualTitle = '',
  String visualDescription = '',
  String itemLabel = '',
  String itemEmoji = '●',
  String itemUnit = 'こ',
  int? totalCount,
  int? groupCount,
  int? perGroupCount,
  int? remainderCount,
  String equationHint = '',
  String thinkingHint = '',
  String visualHint = '',
  String pictureDescription = '',
  String diagramType = '',
  Map<String, String> diagramData = const {},
  List<Map<String, String>> choiceDiagramData = const [],
}) {
  return Question(
    id: id,
    type: type,
    unitId: 'grade3_division',
    promptSchoolJa: school,
    promptEasyJa: easy,
    promptNative: _nativeText(easy),
    choices: choices,
    questionTextRuby: questionTextRuby,
    choicesRuby: choicesRuby,
    correctAnswer: correct,
    correctAnswerText: correctAnswerText,
    correctAnswerTextRuby: correctAnswerTextRuby,
    explanationEasyJa: explanation,
    explanation: explanation,
    explanationRuby: explanationRuby,
    formulaExplanation: formulaExplanation,
    formulaExplanationRuby: formulaExplanationRuby,
    languagePoint: languagePoint,
    languagePointRuby: languagePointRuby,
    vocabularyEntries: vocabularyEntries,
    explanationNative: _nativeText(explanation),
    tags: ['division', 'grade3', 'math', 'no_remainder', ...tags],
    equationHint: equationHint,
    thinkingHint: thinkingHint,
    visualHint: visualHint,
    visualType: visualType,
    visualTitle: visualTitle,
    visualDescription: visualDescription,
    itemLabel: itemLabel,
    itemEmoji: itemEmoji,
    itemUnit: itemUnit,
    totalCount: totalCount,
    groupCount: groupCount,
    perGroupCount: perGroupCount,
    remainderCount: remainderCount,
    pictureDescription: pictureDescription,
    diagramType: diagramType,
    diagramData: diagramData,
    choiceDiagramData: choiceDiagramData,
    vocabulary: vocabulary,
    grade: 3,
    subject: 'math',
    unit: 'division',
  );
}

const _divisionSharingVocabulary = [
  VocabularyEntry(
    term: 'りんご',
    reading: 'りんご',
    simpleJapanese: '赤いくだものです。',
    translations: {
      AppLanguage.portuguese: 'maçã',
      AppLanguage.tagalog: 'mansanas',
      AppLanguage.vietnamese: 'quả táo',
    },
    exampleSentence: '6このりんごを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'クッキー',
    reading: 'くっきー',
    simpleJapanese: 'おかしの名前です。',
    translations: {
      AppLanguage.portuguese: 'biscoito',
      AppLanguage.tagalog: 'cookie / biskwit',
      AppLanguage.vietnamese: 'bánh quy',
    },
    exampleSentence: '8このクッキーを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'あめ',
    reading: 'あめ',
    simpleJapanese: '小さいおかしです。',
    translations: {
      AppLanguage.portuguese: 'bala / doce',
      AppLanguage.tagalog: 'kendi',
      AppLanguage.vietnamese: 'kẹo',
    },
    exampleSentence: '12このあめを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'いちご',
    reading: 'いちご',
    simpleJapanese: '赤いくだものです。',
    translations: {
      AppLanguage.portuguese: 'morango',
      AppLanguage.tagalog: 'strawberry',
      AppLanguage.vietnamese: 'quả dâu',
    },
    exampleSentence: 'いちごが6こあります。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'シール',
    reading: 'しーる',
    simpleJapanese: 'はって使うものです。',
    translations: {
      AppLanguage.portuguese: 'adesivo',
      AppLanguage.tagalog: 'sticker',
      AppLanguage.vietnamese: 'nhãn dán',
    },
    exampleSentence: '9このシールを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'カード',
    reading: 'かーど',
    simpleJapanese: '紙の小さい札のようなものです。',
    translations: {
      AppLanguage.portuguese: 'cartão',
      AppLanguage.tagalog: 'card',
      AppLanguage.vietnamese: 'thẻ',
    },
    exampleSentence: '15このカードを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: 'みかん',
    reading: 'みかん',
    simpleJapanese: 'オレンジに似たくだものです。',
    translations: {
      AppLanguage.portuguese: 'mexerica / tangerina',
      AppLanguage.tagalog: 'mikan / dalanghita',
      AppLanguage.vietnamese: 'quýt',
    },
    exampleSentence: '20このみかんを分けます。',
    category: 'noun',
  ),
  VocabularyEntry(
    term: '同じ数ずつ',
    reading: 'おなじかずずつ',
    simpleJapanese: 'ひとりひとりに、同じ数を分けること。',
    translations: {
      AppLanguage.portuguese: 'a mesma quantidade para cada pessoa',
      AppLanguage.tagalog: 'pare-parehong dami para sa bawat tao',
      AppLanguage.vietnamese: 'cùng một số lượng cho mỗi người',
    },
    exampleSentence: '4人に同じ数ずつ分けます。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '分ける',
    reading: 'わける',
    simpleJapanese: 'ものを、何人かに同じように分けること。',
    translations: {
      AppLanguage.portuguese: 'dividir / distribuir',
      AppLanguage.tagalog: 'hatiin / ipamahagi',
      AppLanguage.vietnamese: 'chia / phân phát',
    },
    exampleSentence: '12このあめを3人に分けます。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '1人分',
    reading: 'ひとりぶん',
    simpleJapanese: '1人がもらう数や量のこと。',
    translations: {
      AppLanguage.portuguese: 'quantidade para uma pessoa',
      AppLanguage.tagalog: 'bahagi para sa isang tao',
      AppLanguage.vietnamese: 'phần cho một người',
    },
    exampleSentence: '1人分は4こです。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '人分',
    reading: 'ひとりぶん',
    simpleJapanese: '1人がもらう数や量のこと。',
    translations: {
      AppLanguage.portuguese: 'quantidade para uma pessoa',
      AppLanguage.tagalog: 'bahagi para sa isang tao',
      AppLanguage.vietnamese: 'phần cho một người',
    },
    exampleSentence: '1人分は4こです。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '人',
    reading: 'にん',
    simpleJapanese: '人の数を数える言い方です。',
    translations: {
      AppLanguage.portuguese: 'pessoa(s)',
      AppLanguage.tagalog: 'tao',
      AppLanguage.vietnamese: 'người',
    },
    exampleSentence: '3人で分けます。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '人数',
    reading: 'にんずう',
    simpleJapanese: '人が何人いるかを表す言葉です。',
    translations: {
      AppLanguage.portuguese: 'número de pessoas',
      AppLanguage.tagalog: 'bilang ng tao',
      AppLanguage.vietnamese: 'số người',
    },
    exampleSentence: '4は分ける人数です。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '何こ',
    reading: 'なんこ',
    simpleJapanese: 'ものの数を聞く言い方です。',
    translations: {
      AppLanguage.portuguese: 'quantos itens',
      AppLanguage.tagalog: 'ilang piraso',
      AppLanguage.vietnamese: 'bao nhiêu cái',
    },
    exampleSentence: '1人分は何こですか。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '何',
    reading: 'なん',
    simpleJapanese: 'わからないものを聞く言葉です。',
    translations: {
      AppLanguage.portuguese: 'o quê / qual',
      AppLanguage.tagalog: 'ano',
      AppLanguage.vietnamese: 'gì / nào',
    },
    exampleSentence: '何の数ですか。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '正しい',
    reading: 'ただしい',
    simpleJapanese: '合っている、という意味です。',
    translations: {
      AppLanguage.portuguese: 'correto',
      AppLanguage.tagalog: 'tama',
      AppLanguage.vietnamese: 'đúng',
    },
    exampleSentence: '正しい式を選びます。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '全部',
    reading: 'ぜんぶ',
    simpleJapanese: 'すべて、という意味です。',
    translations: {
      AppLanguage.portuguese: 'tudo / total',
      AppLanguage.tagalog: 'lahat / kabuuan',
      AppLanguage.vietnamese: 'tất cả / tổng cộng',
    },
    exampleSentence: '全部の8こを分けます。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '数',
    reading: 'かず',
    simpleJapanese: 'いくつあるかを表すものです。',
    translations: {
      AppLanguage.portuguese: 'número / quantidade',
      AppLanguage.tagalog: 'bilang',
      AppLanguage.vietnamese: 'số lượng',
    },
    exampleSentence: '6は全部の数です。',
    category: 'math_language',
  ),
  VocabularyEntry(
    term: '相手',
    reading: 'あいて',
    simpleJapanese: 'いっしょに何かをする人のことです。',
    translations: {
      AppLanguage.portuguese: 'a outra pessoa / pessoa envolvida',
      AppLanguage.tagalog: 'kausap / kasama',
      AppLanguage.vietnamese: 'người cùng tham gia',
    },
    exampleSentence: '分ける相手が4人います。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '意味',
    reading: 'いみ',
    simpleJapanese: '言葉が表していることです。',
    translations: {
      AppLanguage.portuguese: 'significado',
      AppLanguage.tagalog: 'kahulugan',
      AppLanguage.vietnamese: 'ý nghĩa',
    },
    exampleSentence: '言葉の意味を考えます。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '考えます',
    reading: 'かんがえます',
    simpleJapanese: '頭の中で考える、という意味です。',
    translations: {
      AppLanguage.portuguese: 'pensar',
      AppLanguage.tagalog: 'mag-isip',
      AppLanguage.vietnamese: 'suy nghĩ',
    },
    exampleSentence: '式を見て考えます。',
    category: 'school_japanese',
  ),
  VocabularyEntry(
    term: '式',
    reading: 'しき',
    simpleJapanese: '計算を、数字や記号で書いたもの。',
    translations: {
      AppLanguage.portuguese: 'conta / expressão matemática',
      AppLanguage.tagalog: 'pahayag sa matematika',
      AppLanguage.vietnamese: 'phép tính / biểu thức',
    },
    exampleSentence: '12 ÷ 3 は、わり算の式です。',
    category: 'math_language',
  ),
];

Map<AppLanguage, String> _nativeText(String fallback) {
  final portuguese = _portugueseText(fallback);
  if (portuguese == null) return const {};
  return {
    AppLanguage.portuguese: portuguese,
    AppLanguage.tagalog: _tagalogText(fallback) ?? portuguese,
    AppLanguage.vietnamese: _vietnameseText(fallback) ?? portuguese,
  };
}

String? _tagalogText(String source) {
  return switch (source) {
    'りんごが6こあります。2人に同じ数で分けます。1人は何こもらいますか。' =>
      'May 6 na mansanas. Hatiin nang pantay sa 2 tao. Ilang mansanas ang para sa bawat isa?',
    '6こを2人で同じ数ずつ分けるので、6 ÷ 2 = 3。1人分は3こです。' =>
      'Dahil hinati ang 6 mansanas nang pantay sa 2 tao, 6 ÷ 2 = 3. 3 mansanas ang sa bawat isa.',
    'クッキー8こを4人に同じ数で分けます。どの式ですか。' =>
      'May 8 biskwit. Hatiin nang pantay sa 4 tao. Alin ang tamang pahayag?',
    '全部の8こを4人で分けるので、式は8 ÷ 4です。' =>
      'Dahil hinati ang lahat ng 8 biskwit sa 4 tao, ang pahayag ay 8 ÷ 4.',
    'あめが12こあります。3人に同じ数で分けます。1人は何こですか。' =>
      'May 12 kendi. Hatiin nang pantay sa 3 tao. Ilan ang para sa bawat isa?',
    '12 ÷ 3 = 4。1人分は4こです。' => '12 ÷ 3 = 4. 4 ang sa bawat isa.',
    'カード15こを5人で分けます。15 ÷ □ の□は何ですか。' =>
      'May 15 kard. Hatiin sa 5 tao. Anong numero ang papasok sa □ ng 15 ÷ □?',
    '分ける人数は5人なので、式は15 ÷ 5です。' =>
      'Dahil 5 ang bilang ng tao, ang pahayag ay 15 ÷ 5.',
    'みかん20こを4人に同じ数で分けます。どの式ですか。' =>
      'May 20 dalanghita. Hatiin nang pantay sa 4 tao. Alin ang tamang pahayag?',
    '20は全部の数、4は分ける人数です。式は20 ÷ 4。答えは5こです。' =>
      '20 ang kabuuan, at 4 ang bilang ng tao. Ang pahayag ay 20 ÷ 4. Ang sagot ay 5.',
    'いちごが6こあります。3人で分けます。全部で何こありますか。' =>
      'May 6 na strawberry. Hatiin sa 3 tao. Ilan lahat ang strawberry?',
    'はじめにあるいちごは6こです。6こを3人で分けるので、式は6 ÷ 3です。' =>
      'Sa simula, may 6 na strawberry. Dahil hinati ang 6 sa 3 tao, ang pahayag ay 6 ÷ 3.',
    'シール9こを3人に同じ数で分けます。合う図はどれですか。' =>
      'May 9 na sticker. Hatiin nang pantay sa 3 tao. Aling larawan ang tumutugma?',
    '3人に3こずつ入っている図が正しいです。' =>
      'Tama ang larawang may 3 sticker para sa bawat isa sa 3 tao.',
    'えんぴつ18本を6人に同じ数で分けます。1人は何本ですか。' =>
      'May 18 lapis. Hatiin nang pantay sa 6 tao. Ilang lapis ang sa bawat isa?',
    '18 ÷ 6 = 3。1人分は3本です。' => '18 ÷ 6 = 3. 3 lapis ang sa bawat isa.',
    'クッキー8こを、1人に2こずつ分けます。何人分できますか。' =>
      'May 8 biskwit. Kung 2 biskwit ang sa bawat tao, para sa ilang tao iyon?',
    '8 ÷ 2 = 4。2こずつのまとまりが4つできるので、4人です。' =>
      '8 ÷ 2 = 4. Dahil 4 na grupong tig-2, sapat sa 4 na tao.',
    'あめ12こを、1人に3こずつ分けます。どの式ですか。' =>
      'May 12 kendi. Kung 3 kendi ang sa bawat tao, alin ang tamang pahayag?',
    '全部の12こを、3こずつのまとまりにするので、12 ÷ 3です。' =>
      'Dahil ginawang grupong tig-3 ang 12 kendi, ang pahayag ay 12 ÷ 3.',
    'カード15まいを、1人に5まいずつ分けます。何人分できますか。' =>
      'May 15 kard. Kung 5 kard ang sa bawat tao, para sa ilang tao iyon?',
    '15 ÷ 5 = 3。3人に分けられます。' => '15 ÷ 5 = 3. Mahahati sa 3 tao.',
    'ビー玉18こを、1人に6こずつ分けます。18 ÷ □ の□は何ですか。' =>
      'May 18 bolitas. Kung 6 bolitas ang sa bawat tao, anong numero ang papasok sa □ ng 18 ÷ □?',
    '1人に6こずつ分けるので、式は18 ÷ 6です。' =>
      'Dahil 6 ang ibinibigay sa bawat tao, ang pahayag ay 18 ÷ 6.',
    'シール24こを、1人に4こずつ分けます。どの式ですか。' =>
      'May 24 na sticker. Kung 4 na sticker ang sa bawat tao, alin ang tamang pahayag?',
    '全部の24こを、1人分の4こで分けるので、式は24 ÷ 4です。' =>
      'Dahil hinati ang 24 sticker sa bahaging tig-4, ang pahayag ay 24 ÷ 4.',
    'いちご6こを、1人に2こずつ分けます。何人分できますか。' =>
      'May 6 na strawberry. Kung 2 strawberry ang sa bawat tao, para sa ilang tao iyon?',
    '6こを2こずつのまとまりにすると、3つのまとまりができます。だから、3人に分けられます。' =>
      'Kung gagawing grupong tig-2 ang 6 strawberry, 3 grupo ang magagawa. Kaya mahahati sa 3 tao.',
    'あめ10こを、1人に2こずつ分けます。合う図はどれですか。' =>
      'May 10 kendi. Kung 2 kendi ang sa bawat tao, aling larawan ang tumutugma?',
    '10 ÷ 2 = 5。2こずつの組が5つある図です。' =>
      '10 ÷ 2 = 5. Iyon ang larawang may 5 grupong tig-2.',
    'えんぴつ21本を、1人に3本ずつ分けます。何人分できますか。' =>
      'May 21 lapis. Kung 3 lapis ang sa bawat tao, para sa ilang tao iyon?',
    '21 ÷ 3 = 7。答えの単位は人です。' => '21 ÷ 3 = 7. Tao ang yunit ng sagot.',
    '0こを3人で分けます。1人分は何こですか。' =>
      'May 0 strawberry. Kung hahatiin sa 3 tao, ilan ang sa bawat isa?',
    '0こを分けるので、1人分も0こです。0 ÷ 3 = 0 です。' =>
      'Dahil 0 ang hinahati, 0 din ang sa bawat isa. 0 ÷ 3 = 0.',
    '6こを1人で分けます。1人分は何こですか。' =>
      'May 6 na strawberry. Kung 1 tao lang ang hahatiin, ilan ang sa taong iyon?',
    '6こを1人で分けるので、全部その人の分です。6 ÷ 1 = 6 です。' =>
      'Dahil 1 tao ang pinaghahatian, lahat ay sa kanya. 6 ÷ 1 = 6.',
    '6こを6人で分けます。1人分は何こですか。' =>
      'May 6 na strawberry. Hatiin sa 6 tao. Ilan ang sa bawat isa?',
    '6こを6人で同じ数ずつ分けると、1人分は1こです。6 ÷ 6 = 1 です。' =>
      'Kung hahatiin nang pantay ang 6 sa 6 tao, 1 ang sa bawat isa. 6 ÷ 6 = 1.',
    'あめが0こです。4人で分けます。どの式ですか。' =>
      'May 0 kendi. Hatiin sa 4 tao. Alin ang tamang pahayag?',
    '全部の数が0こなので、式は0 ÷ 4です。0でわる式は選びません。' =>
      'Dahil 0 ang kabuuan, ang pahayag ay 0 ÷ 4. Huwag pumili ng pahayag na hinahati sa 0.',
    '9こを1人で分けます。1人分は何こですか。' =>
      'May 9 piraso. Kung 1 tao lang, ilan ang sa kanya?',
    '1人で分けるので、9こ全部がその人の分です。9 ÷ 1 = 9 です。' =>
      'Dahil 1 tao, lahat ng 9 ay sa kanya. 9 ÷ 1 = 9.',
    '8こを8人で分けます。1人分は何こですか。' =>
      'May 8 piraso. Hatiin sa 8 tao. Ilan ang sa bawat isa?',
    '8こを8人で分けると、1人分は1こです。8 ÷ 8 = 1 です。' =>
      'Kung hahatiin ang 8 sa 8 tao, 1 ang sa bawat isa. 8 ÷ 8 = 1.',
    '7を7でわります。答えは何ですか。' => 'Hatiin ang 7 sa 7. Ano ang sagot?',
    '同じ数でわると、答えは1です。7 ÷ 7 = 1 です。' =>
      'Kapag hinati sa parehong numero, 1 ang sagot. 7 ÷ 7 = 1.',
    '6 ÷ 1 = 6 の1は、どんな数ですか。' =>
      'Sa 6 ÷ 1 = 6, anong numero ang kinakatawan ng 1?',
    '6 ÷ 1 = 6 の1は、分ける人数です。1人で分けるので、1人分は6こです。' =>
      'Sa 6 ÷ 1 = 6, ang 1 ay bilang ng tao. Dahil 1 tao, 6 ang sa kanya.',
    '6を0でわることについて、正しいものを選びます。' =>
      'Piliin ang tamang pangungusap tungkol sa paghahati ng 6 sa 0.',
    '0人には分けられないので、6 ÷ 0 の答えはありません。' =>
      'Hindi mahahati sa 0 tao, kaya walang sagot ang 6 ÷ 0.',
    '24 ÷ 6 の答えを、かけ算で見つけます。どのかけ算を使いますか。' =>
      'Hanapin ang sagot ng 24 ÷ 6 gamit ang multiplikasyon. Aling multiplikasyon ang gagamitin?',
    '6 × 4 = 24だから、24 ÷ 6 = 4です。' => 'Dahil 6 × 4 = 24, kaya 24 ÷ 6 = 4.',
    '18 ÷ 3 と 3 × □ = 18 を見ます。□に入る数はどれですか。' =>
      'Tingnan ang 18 ÷ 3 at 3 × □ = 18. Anong numero ang papasok sa □?',
    '□には同じ6が入ります。18 ÷ 3 = 6、3 × 6 = 18です。' =>
      'Parehong 6 ang papasok sa dalawang lugar. 18 ÷ 3 = 6 at 3 × 6 = 18.',
    'りんご21こを7人で同じ数ずつ分けます。1人分は何こですか。' =>
      'May 21 mansanas. Hatiin nang pantay sa 7 tao. Ilang mansanas ang sa bawat isa?',
    '7 × 3 = 21だから、21 ÷ 7 = 3です。1人分は3こです。' =>
      'Dahil 7 × 3 = 21, kaya 21 ÷ 7 = 3. 3 mansanas ang sa bawat isa.',
    'わり算とかけ算のつながりを、図と式で見ます。' =>
      'Tingnan natin ang ugnayan ng dibisyon at multiplikasyon sa larawan at pahayag.',
    'かけ算を使って、□に入る数を見つけます。' =>
      'Ginagamit ang multiplikasyon para hanapin ang numerong papasok sa □.',
    'かけ算を使うと、わり算の答えを見つけられます。' =>
      'Sa multiplikasyon, mahanap ang sagot ng dibisyon.',
    '36 ÷ 6 の答えを、かけ算で見つけます。' =>
      'Hanapin ang sagot ng 36 ÷ 6 gamit ang multiplikasyon.',
    '6 × 6 = 36だから、36 ÷ 6 = 6です。' => 'Dahil 6 × 6 = 36, kaya 36 ÷ 6 = 6.',
    '28 ÷ 4 と 4 × □ = 28 を見ます。' => 'Tingnan ang 28 ÷ 4 at 4 × □ = 28.',
    '4 × 7 = 28だから、28 ÷ 4 = 7です。' => 'Dahil 4 × 7 = 28, kaya 28 ÷ 4 = 7.',
    _ => null,
  };
}

String? _vietnameseText(String source) {
  return switch (source) {
    'りんごが6こあります。2人に同じ数で分けます。1人は何こもらいますか。' =>
      'Có 6 quả táo. Chia đều cho 2 người. Mỗi người nhận bao nhiêu quả táo?',
    '6こを2人で同じ数ずつ分けるので、6 ÷ 2 = 3。1人分は3こです。' =>
      'Vì chia đều 6 quả táo cho 2 người nên 6 ÷ 2 = 3. Mỗi người được 3 quả.',
    'クッキー8こを4人に同じ数で分けます。どの式ですか。' =>
      'Có 8 cái bánh quy. Chia đều cho 4 người. Phép tính nào đúng?',
    '全部の8こを4人で分けるので、式は8 ÷ 4です。' =>
      'Vì chia hết 8 cái bánh cho 4 người nên phép tính là 8 ÷ 4.',
    'あめが12こあります。3人に同じ数で分けます。1人は何こですか。' =>
      'Có 12 viên kẹo. Chia đều cho 3 người. Mỗi người được bao nhiêu?',
    '12 ÷ 3 = 4。1人分は4こです。' => '12 ÷ 3 = 4. Mỗi người được 4.',
    'カード15こを5人で分けます。15 ÷ □ の□は何ですか。' =>
      'Có 15 tấm thẻ. Chia cho 5 người. Số nào điền vào □ trong 15 ÷ □?',
    '分ける人数は5人なので、式は15 ÷ 5です。' => 'Vì số người là 5 nên phép tính là 15 ÷ 5.',
    'みかん20こを4人に同じ数で分けます。どの式ですか。' =>
      'Có 20 quả quýt. Chia đều cho 4 người. Phép tính nào đúng?',
    '20は全部の数、4は分ける人数です。式は20 ÷ 4。答えは5こです。' =>
      '20 là tổng, 4 là số người. Phép tính là 20 ÷ 4. Đáp án là 5.',
    'いちごが6こあります。3人で分けます。全部で何こありますか。' =>
      'Có 6 quả dâu. Chia cho 3 người. Tổng cộng có bao nhiêu quả?',
    'はじめにあるいちごは6こです。6こを3人で分けるので、式は6 ÷ 3です。' =>
      'Lúc đầu có 6 quả dâu. Vì chia 6 cho 3 người nên phép tính là 6 ÷ 3.',
    'シール9こを3人に同じ数で分けます。合う図はどれですか。' =>
      'Có 9 tem. Chia đều cho 3 người. Hình nào khớp?',
    '3人に3こずつ入っている図が正しいです。' => 'Hình đúng là mỗi người trong 3 người có 3 tem.',
    'えんぴつ18本を6人に同じ数で分けます。1人は何本ですか。' =>
      'Có 18 cây bút chì. Chia đều cho 6 người. Mỗi người được bao nhiêu cây?',
    '18 ÷ 6 = 3。1人分は3本です。' => '18 ÷ 6 = 3. Mỗi người được 3 cây bút chì.',
    'クッキー8こを、1人に2こずつ分けます。何人分できますか。' =>
      'Có 8 cái bánh. Mỗi người 2 cái thì đủ cho bao nhiêu người?',
    '8 ÷ 2 = 4。2こずつのまとまりが4つできるので、4人です。' =>
      '8 ÷ 2 = 4. Vì có 4 nhóm 2 cái nên đủ cho 4 người.',
    'あめ12こを、1人に3こずつ分けます。どの式ですか。' =>
      'Có 12 viên kẹo. Mỗi người 3 viên thì phép tính nào đúng?',
    '全部の12こを、3こずつのまとまりにするので、12 ÷ 3です。' =>
      'Vì gom 12 viên thành nhóm 3 nên phép tính là 12 ÷ 3.',
    'カード15まいを、1人に5まいずつ分けます。何人分できますか。' =>
      'Có 15 tấm thẻ. Mỗi người 5 tấm thì đủ cho bao nhiêu người?',
    '15 ÷ 5 = 3。3人に分けられます。' => '15 ÷ 5 = 3. Chia được cho 3 người.',
    'ビー玉18こを、1人に6こずつ分けます。18 ÷ □ の□は何ですか。' =>
      'Có 18 viên bi. Mỗi người 6 viên thì số nào điền vào □ trong 18 ÷ □?',
    '1人に6こずつ分けるので、式は18 ÷ 6です。' => 'Vì mỗi người được 6 nên phép tính là 18 ÷ 6.',
    'シール24こを、1人に4こずつ分けます。どの式ですか。' =>
      'Có 24 tem. Mỗi người 4 tem thì phép tính nào đúng?',
    '全部の24こを、1人分の4こで分けるので、式は24 ÷ 4です。' =>
      'Vì chia 24 tem thành phần 4 nên phép tính là 24 ÷ 4.',
    'いちご6こを、1人に2こずつ分けます。何人分できますか。' =>
      'Có 6 quả dâu. Mỗi người 2 quả thì đủ cho bao nhiêu người?',
    '6こを2こずつのまとまりにすると、3つのまとまりができます。だから、3人に分けられます。' =>
      'Gom 6 quả thành nhóm 2 thì được 3 nhóm. Vì vậy chia được cho 3 người.',
    'あめ10こを、1人に2こずつ分けます。合う図はどれですか。' =>
      'Có 10 viên kẹo. Mỗi người 2 viên thì hình nào khớp?',
    '10 ÷ 2 = 5。2こずつの組が5つある図です。' => '10 ÷ 2 = 5. Đó là hình có 5 nhóm 2.',
    'えんぴつ21本を、1人に3本ずつ分けます。何人分できますか。' =>
      'Có 21 cây bút chì. Mỗi người 3 cây thì đủ cho bao nhiêu người?',
    '21 ÷ 3 = 7。答えの単位は人です。' => '21 ÷ 3 = 7. Đơn vị đáp án là người.',
    '0こを3人で分けます。1人分は何こですか。' =>
      'Có 0 quả dâu. Chia cho 3 người thì mỗi người được bao nhiêu?',
    '0こを分けるので、1人分も0こです。0 ÷ 3 = 0 です。' =>
      'Vì chia 0 nên mỗi người được 0. 0 ÷ 3 = 0.',
    '6こを1人で分けます。1人分は何こですか。' =>
      'Có 6 quả dâu. Chia cho 1 người thì người đó được bao nhiêu?',
    '6こを1人で分けるので、全部その人の分です。6 ÷ 1 = 6 です。' =>
      'Vì chia cho 1 người nên tất cả thuộc người đó. 6 ÷ 1 = 6.',
    '6こを6人で分けます。1人分は何こですか。' =>
      'Có 6 quả dâu. Chia cho 6 người. Mỗi người được bao nhiêu?',
    '6こを6人で同じ数ずつ分けると、1人分は1こです。6 ÷ 6 = 1 です。' =>
      'Chia đều 6 cho 6 người thì mỗi người được 1. 6 ÷ 6 = 1.',
    'あめが0こです。4人で分けます。どの式ですか。' =>
      'Có 0 viên kẹo. Chia cho 4 người. Phép tính nào đúng?',
    '全部の数が0こなので、式は0 ÷ 4です。0でわる式は選びません。' =>
      'Vì tổng là 0 nên phép tính là 0 ÷ 4. Không chọn phép chia cho 0.',
    '9こを1人で分けます。1人分は何こですか。' =>
      'Có 9 món. Chia cho 1 người thì người đó được bao nhiêu?',
    '1人で分けるので、9こ全部がその人の分です。9 ÷ 1 = 9 です。' =>
      'Vì chia cho 1 người nên cả 9 món thuộc người đó. 9 ÷ 1 = 9.',
    '8こを8人で分けます。1人分は何こですか。' =>
      'Có 8 món. Chia cho 8 người. Mỗi người được bao nhiêu?',
    '8こを8人で分けると、1人分は1こです。8 ÷ 8 = 1 です。' =>
      'Chia 8 cho 8 người thì mỗi người được 1. 8 ÷ 8 = 1.',
    '7を7でわります。答えは何ですか。' => 'Chia 7 cho 7. Đáp án là bao nhiêu?',
    '同じ数でわると、答えは1です。7 ÷ 7 = 1 です。' =>
      'Chia một số cho chính nó thì đáp án là 1. 7 ÷ 7 = 1.',
    '6 ÷ 1 = 6 の1は、どんな数ですか。' => 'Trong 6 ÷ 1 = 6, số 1 đại diện cho gì?',
    '6 ÷ 1 = 6 の1は、分ける人数です。1人で分けるので、1人分は6こです。' =>
      'Trong 6 ÷ 1 = 6, số 1 là số người. Vì chia cho 1 người nên người đó được 6.',
    '6を0でわることについて、正しいものを選びます。' => 'Chọn câu đúng về việc chia 6 cho 0.',
    '0人には分けられないので、6 ÷ 0 の答えはありません。' =>
      'Không thể chia cho 0 người nên 6 ÷ 0 không có đáp án.',
    '24 ÷ 6 の答えを、かけ算で見つけます。どのかけ算を使いますか。' =>
      'Tìm đáp án 24 ÷ 6 bằng phép nhân. Dùng phép nhân nào?',
    '6 × 4 = 24だから、24 ÷ 6 = 4です。' => 'Vì 6 × 4 = 24 nên 24 ÷ 6 = 4.',
    '18 ÷ 3 と 3 × □ = 18 を見ます。□に入る数はどれですか。' =>
      'Nhìn 18 ÷ 3 và 3 × □ = 18. Số nào điền vào □?',
    '□には同じ6が入ります。18 ÷ 3 = 6、3 × 6 = 18です。' =>
      'Cùng số 6 điền vào cả hai chỗ. 18 ÷ 3 = 6 và 3 × 6 = 18.',
    'りんご21こを7人で同じ数ずつ分けます。1人分は何こですか。' =>
      'Có 21 quả táo. Chia đều cho 7 người. Mỗi người được bao nhiêu quả?',
    '7 × 3 = 21だから、21 ÷ 7 = 3です。1人分は3こです。' =>
      'Vì 7 × 3 = 21 nên 21 ÷ 7 = 3. Mỗi người được 3 quả táo.',
    'わり算とかけ算のつながりを、図と式で見ます。' =>
      'Hãy xem mối liên hệ giữa phép chia và phép nhân bằng hình và phép tính.',
    'かけ算を使って、□に入る数を見つけます。' => 'Dùng phép nhân để tìm số điền vào □.',
    'かけ算を使うと、わり算の答えを見つけられます。' => 'Nhờ phép nhân, ta tìm được đáp án phép chia.',
    '36 ÷ 6 の答えを、かけ算で見つけます。' => 'Tìm đáp án 36 ÷ 6 bằng phép nhân.',
    '6 × 6 = 36だから、36 ÷ 6 = 6です。' => 'Vì 6 × 6 = 36 nên 36 ÷ 6 = 6.',
    '28 ÷ 4 と 4 × □ = 28 を見ます。' => 'Nhìn 28 ÷ 4 và 4 × □ = 28.',
    '4 × 7 = 28だから、28 ÷ 4 = 7です。' => 'Vì 4 × 7 = 28 nên 28 ÷ 4 = 7.',
    _ => null,
  };
}

String? _portugueseText(String source) {
  return switch (source) {
    'りんごが6こあります。2人に同じ数で分けます。1人は何こもらいますか。' =>
      'Há 6 maçãs. Vamos dividir igualmente entre 2 pessoas. Quantas maçãs cada pessoa recebe?',
    '6こを2人で同じ数ずつ分けるので、6 ÷ 2 = 3。1人分は3こです。' =>
      'Como dividimos 6 maçãs igualmente entre 2 pessoas, 6 ÷ 2 = 3. Cada pessoa recebe 3 maçãs.',
    'クッキー8こを4人に同じ数で分けます。どの式ですか。' =>
      'Há 8 biscoitos. Vamos dividir igualmente entre 4 pessoas. Qual é a conta correta?',
    '全部の8こを4人で分けるので、式は8 ÷ 4です。' =>
      'Como dividimos todos os 8 biscoitos entre 4 pessoas, a conta é 8 ÷ 4.',
    'あめが12こあります。3人に同じ数で分けます。1人は何こですか。' =>
      'Há 12 balas. Vamos dividir igualmente entre 3 pessoas. Quantas balas cada pessoa recebe?',
    '12 ÷ 3 = 4。1人分は4こです。' => '12 ÷ 3 = 4. Cada pessoa recebe 4.',
    'カード15こを5人で分けます。15 ÷ □ の□は何ですか。' =>
      'Há 15 cartões. Vamos dividir entre 5 pessoas. Que número entra no □ em 15 ÷ □?',
    '分ける人数は5人なので、式は15 ÷ 5です。' =>
      'Como o número de pessoas é 5, a conta é 15 ÷ 5.',
    'みかん20こを4人に同じ数で分けます。どの式ですか。' =>
      'Há 20 mexericas. Vamos dividir igualmente entre 4 pessoas. Qual é a conta correta?',
    '20は全部の数、4は分ける人数です。式は20 ÷ 4。答えは5こです。' =>
      '20 é o total, e 4 é o número de pessoas. A conta é 20 ÷ 4. A resposta é 5.',
    'いちごが6こあります。3人で分けます。全部で何こありますか。' =>
      'Há 6 morangos. Vamos dividir entre 3 pessoas. Quantos morangos há no total?',
    'はじめにあるいちごは6こです。6こを3人で分けるので、式は6 ÷ 3です。' =>
      'No começo, há 6 morangos. Como dividimos 6 morangos entre 3 pessoas, a conta é 6 ÷ 3.',
    'シール9こを3人に同じ数で分けます。合う図はどれですか。' =>
      'Há 9 adesivos. Vamos dividir igualmente entre 3 pessoas. Qual desenho combina?',
    '3人に3こずつ入っている図が正しいです。' =>
      'O desenho correto mostra 3 adesivos para cada uma das 3 pessoas.',
    'えんぴつ18本を6人に同じ数で分けます。1人は何本ですか。' =>
      'Há 18 lápis. Vamos dividir igualmente entre 6 pessoas. Quantos lápis cada pessoa recebe?',
    '18 ÷ 6 = 3。1人分は3本です。' => '18 ÷ 6 = 3. Cada pessoa recebe 3 lápis.',
    'クッキー8こを、1人に2こずつ分けます。何人分できますか。' =>
      'Há 8 biscoitos. Dando 2 biscoitos para cada pessoa, para quantas pessoas dá?',
    '8 ÷ 2 = 4。2こずつのまとまりが4つできるので、4人です。' =>
      '8 ÷ 2 = 4. Como formamos 4 grupos de 2 biscoitos, dá para 4 pessoas.',
    'あめ12こを、1人に3こずつ分けます。どの式ですか。' =>
      'Há 12 balas. Dando 3 balas para cada pessoa, qual é a conta correta?',
    '全部の12こを、3こずつのまとまりにするので、12 ÷ 3です。' =>
      'Como agrupamos as 12 balas em grupos de 3, a conta é 12 ÷ 3.',
    'カード15まいを、1人に5まいずつ分けます。何人分できますか。' =>
      'Há 15 cartões. Dando 5 cartões para cada pessoa, para quantas pessoas dá?',
    '15 ÷ 5 = 3。3人に分けられます。' =>
      '15 ÷ 5 = 3. Dá para dividir para 3 pessoas.',
    'ビー玉18こを、1人に6こずつ分けます。18 ÷ □ の□は何ですか。' =>
      'Há 18 bolinhas. Dando 6 bolinhas para cada pessoa, que número entra no □ em 18 ÷ □?',
    '1人に6こずつ分けるので、式は18 ÷ 6です。' =>
      'Como damos 6 para cada pessoa, a conta é 18 ÷ 6.',
    'シール24こを、1人に4こずつ分けます。どの式ですか。' =>
      'Há 24 adesivos. Dando 4 adesivos para cada pessoa, qual é a conta correta?',
    '全部の24こを、1人分の4こで分けるので、式は24 ÷ 4です。' =>
      'Como dividimos os 24 adesivos em partes de 4, a conta é 24 ÷ 4.',
    'いちご6こを、1人に2こずつ分けます。何人分できますか。' =>
      'Há 6 morangos. Dando 2 morangos para cada pessoa, para quantas pessoas dá?',
    '6こを2こずつのまとまりにすると、3つのまとまりができます。だから、3人に分けられます。' =>
      'Ao fazer grupos de 2 com 6 morangos, conseguimos 3 grupos. Por isso, dá para dividir para 3 pessoas.',
    'あめ10こを、1人に2こずつ分けます。合う図はどれですか。' =>
      'Há 10 balas. Dando 2 balas para cada pessoa, qual desenho combina?',
    '10 ÷ 2 = 5。2こずつの組が5つある図です。' =>
      '10 ÷ 2 = 5. É o desenho com 5 grupos de 2.',
    'えんぴつ21本を、1人に3本ずつ分けます。何人分できますか。' =>
      'Há 21 lápis. Dando 3 lápis para cada pessoa, para quantas pessoas dá?',
    '21 ÷ 3 = 7。答えの単位は人です。' =>
      '21 ÷ 3 = 7. A unidade da resposta é pessoas.',
    '0こを3人で分けます。1人分は何こですか。' =>
      'Há 0 morangos. Dividindo entre 3 pessoas, quantos cada pessoa recebe?',
    '0こを分けるので、1人分も0こです。0 ÷ 3 = 0 です。' =>
      'Como estamos dividindo 0, cada pessoa recebe 0. 0 ÷ 3 = 0.',
    '6こを1人で分けます。1人分は何こですか。' =>
      'Há 6 morangos. Dividindo com 1 pessoa, quantos essa pessoa recebe?',
    '6こを1人で分けるので、全部その人の分です。6 ÷ 1 = 6 です。' =>
      'Como dividimos 6 com 1 pessoa, tudo fica para essa pessoa. 6 ÷ 1 = 6.',
    '6こを6人で分けます。1人分は何こですか。' =>
      'Há 6 morangos. Dividindo entre 6 pessoas, quantos cada pessoa recebe?',
    '6こを6人で同じ数ずつ分けると、1人分は1こです。6 ÷ 6 = 1 です。' =>
      'Dividindo 6 igualmente entre 6 pessoas, cada pessoa recebe 1. 6 ÷ 6 = 1.',
    'あめが0こです。4人で分けます。どの式ですか。' =>
      'Há 0 balas. Vamos dividir entre 4 pessoas. Qual é a conta correta?',
    '全部の数が0こなので、式は0 ÷ 4です。0でわる式は選びません。' =>
      'Como o total é 0, a conta é 0 ÷ 4. Não escolhemos uma conta dividindo por 0.',
    '9こを1人で分けます。1人分は何こですか。' =>
      'Há 9 itens. Dividindo com 1 pessoa, quantos essa pessoa recebe?',
    '1人で分けるので、9こ全部がその人の分です。9 ÷ 1 = 9 です。' =>
      'Como dividimos com 1 pessoa, todos os 9 itens ficam para essa pessoa. 9 ÷ 1 = 9.',
    '8こを8人で分けます。1人分は何こですか。' =>
      'Há 8 itens. Dividindo entre 8 pessoas, quantos cada pessoa recebe?',
    '8こを8人で分けると、1人分は1こです。8 ÷ 8 = 1 です。' =>
      'Dividindo 8 entre 8 pessoas, cada pessoa recebe 1. 8 ÷ 8 = 1.',
    '7を7でわります。答えは何ですか。' =>
      'Dividimos 7 por 7. Qual é a resposta?',
    '同じ数でわると、答えは1です。7 ÷ 7 = 1 です。' =>
      'Quando dividimos um número por ele mesmo, a resposta é 1. 7 ÷ 7 = 1.',
    '6 ÷ 1 = 6 の1は、どんな数ですか。' =>
      'Em 6 ÷ 1 = 6, que número o 1 representa?',
    '6 ÷ 1 = 6 の1は、分ける人数です。1人で分けるので、1人分は6こです。' =>
      'Em 6 ÷ 1 = 6, o 1 representa o número de pessoas. Como dividimos com 1 pessoa, essa pessoa recebe 6.',
    '6を0でわることについて、正しいものを選びます。' =>
      'Escolha a afirmação correta sobre dividir 6 por 0.',
    '0人には分けられないので、6 ÷ 0 の答えはありません。' =>
      'Como não dá para dividir entre 0 pessoas, 6 ÷ 0 não tem resposta.',
    '24 ÷ 6 の答えを、かけ算で見つけます。どのかけ算を使いますか。' =>
      'Vamos encontrar a resposta de 24 ÷ 6 usando a multiplicação. Qual multiplicação usamos?',
    '6 × 4 = 24だから、24 ÷ 6 = 4です。' =>
      'Como 6 × 4 = 24, então 24 ÷ 6 = 4.',
    '18 ÷ 3 と 3 × □ = 18 を見ます。□に入る数はどれですか。' =>
      'Observe 18 ÷ 3 e 3 × □ = 18. Qual número entra no □?',
    '□には同じ6が入ります。18 ÷ 3 = 6、3 × 6 = 18です。' =>
      'O mesmo número 6 entra nos dois lugares. 18 ÷ 3 = 6 e 3 × 6 = 18.',
    'りんご21こを7人で同じ数ずつ分けます。1人分は何こですか。' =>
      'Há 21 maçãs. Dividindo igualmente entre 7 pessoas, quantas maçãs cada pessoa recebe?',
    '7 × 3 = 21だから、21 ÷ 7 = 3です。1人分は3こです。' =>
      'Como 7 × 3 = 21, então 21 ÷ 7 = 3. Cada pessoa recebe 3 maçãs.',
    'わり算とかけ算のつながりを、図と式で見ます。' =>
      'Vamos ver a ligação entre divisão e multiplicação com desenhos e contas.',
    'かけ算を使って、□に入る数を見つけます。' =>
      'Usamos a multiplicação para encontrar o número que entra no □.',
    'かけ算を使うと、わり算の答えを見つけられます。' =>
      'Usando a multiplicação, podemos encontrar a resposta da divisão.',
    '36 ÷ 6 の答えを、かけ算で見つけます。' =>
      'Vamos encontrar a resposta de 36 ÷ 6 usando a multiplicação.',
    '6 × 6 = 36だから、36 ÷ 6 = 6です。' =>
      'Como 6 × 6 = 36, então 36 ÷ 6 = 6.',
    '28 ÷ 4 と 4 × □ = 28 を見ます。' =>
      'Observe 28 ÷ 4 e 4 × □ = 28.',
    '4 × 7 = 28だから、28 ÷ 4 = 7です。' =>
      'Como 4 × 7 = 28, então 28 ÷ 4 = 7.',
    _ => null,
  };
}
